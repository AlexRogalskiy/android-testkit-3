# android-mvp
MVP architecture with Butterknife and Retrofite library
