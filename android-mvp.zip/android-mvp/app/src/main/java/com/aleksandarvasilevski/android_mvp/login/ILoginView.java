package com.aleksandarvasilevski.android_mvp.login;


public interface ILoginView {

    void loginSuccess();
    void loginFailed();
}
