package com.aleksandarvasilevski.android_mvp.register;


public interface IRegisterView {
    void registerSuccess();
    void registerFailed();
}
